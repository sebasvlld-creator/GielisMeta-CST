clc
clear all
%parámetros de entrada
w=input("Valor del ancho del substrato: ");
l=input("Valor del largo del substrato: ");
z=input("Valor del espesor del substrato: ");
z1=input("Valor del espesor del cobre: ");
a=2;%aca se varía el tamaño del mtm
b=2;%igual aca
m=8;%lados
n1=7;
n2=8;
n3=2;
[n,d]=rat(m); %rational form of m
%Build CST Model
CST=CST_MicrowaveStudio('C:\Users\sebastianmontoya\Desktop\abc','Simulation.cst');
CST.setSolver('frequency');

%define the first 2 modes of the floquet port
CST.defineFloquetModes(2)
CST.setFreq(1, 10);

Z = [-z -z-z1];

CST.addParameter('Er',4.4);
CST.addParameter('Mue',1);
CST.addParameter('W',w);
CST.addParameter('L',l);
CST.addParameter('z',z);


%nombre del bloque, permitividad, permeabilidad y color del material
CST.addNormalMaterial('Material_2','Er','Mue',[1 1 1]);
CST.addNormalMaterial('FR4',4.3,1,[0 1 0]);

CST.addBrick([-w/2 w/2],[-l/2 l/2],[0 -z],'Brick1','Component1','FR4');
CST.addBrick([-w/2 w/2],[-l/2 l/2],[-z -z-z1/2],'Tierra','Component1','Copper (annealed)');

if mod(n,2)==0 || (a==b && n2==n3)
    u=2*d;
else
    u=4*d;
end
theta=linspace(0,u*pi,150);
ftheta=ones(size(theta));

rho=ftheta.*(abs(cos(m.*theta./4)./a).^n2+abs(sin(m.*theta./4)./b).^n3).^(-1/n1);
[x,y]=pol2cart(theta,rho);

points=[];
for i= 1:length(x)
    for j= 1:length(y)
        points(j,:)=[x(j), y(j)];
    end
end 
plot(points)

CST.addPolygonBlock(points,[z1],'a','component2','Copper (annealed)');

points2=points/1.5;

CST.addPolygonBlock(points2,[z1],'a1','component2','Copper (annealed)');

%CST.subtractObject('component2:a','component2:a1')

points3=points2/1.4;

CST.addPolygonBlock(points3,[z1],'a2','component2','Copper (annealed)');

points4=points3/3;%1.33
CST.addPolygonBlock(points4,[z1],'a3','component2','Copper (annealed)');

%CST.subtractObject('component2:a2','component2:a3')

plot(x,y)
axis equal